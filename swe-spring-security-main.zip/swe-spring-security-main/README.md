# Lab 12 on Spring Security
#### Implementing User Authentication and Role Based Authorization using spring security
For this Lab12, proceed to implement User Authentication and Role-based Authorization using Spring Security, for your eRegistrar web application (from Lab10).

In your solution, define the following 3 users and roles:

**1.** Username: ana.admin@eregistrar.com - Role: ADMIN

**2.** Username: bob.registrar@eregistrar.com - Role: REGISTRAR

**3.** Username: carlos.student@eregistrar.com - Role: STUDENT

_Note:_ Use the `fairfieldlibrarywebappsec` example secure webapp code as a guide.

**Enjoy!**